# StarWinCasino Backend (Free Starter)

- Express + Socket.io
- Free deploy on Render (render.yaml included)

## Local run
```bash
npm install
npm run dev
```

Backend runs on `http://localhost:4000` by default.
